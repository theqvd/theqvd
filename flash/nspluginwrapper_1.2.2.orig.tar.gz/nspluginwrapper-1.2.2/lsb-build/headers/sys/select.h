#ifndef _SYS_SELECT_H_
#define _SYS_SELECT_H_


#ifdef __cplusplus
extern "C" {
#endif


#define NFDBITS	(8 * sizeof (long))



#ifdef __cplusplus
}
#endif
#endif
