void dladdr() {} ;
void dlclose() {} ;
void dlerror() {} ;
void dlopen() {} ;
void dlsym() {} ;
