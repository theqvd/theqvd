void g_thread_init() {} ;
void g_thread_init_with_errorcheck_mutexes() {} ;
